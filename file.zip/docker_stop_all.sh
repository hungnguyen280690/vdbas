#!/bin/bash

# Configuration and colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

ROOT_DIR="$(pwd)"

echo -e "${BLUE}========================================================${NC}"
echo -e "${BLUE}    VDBAS Docker Compose Stop All Services Utility      ${NC}"
echo -e "${BLUE}========================================================${NC}"

# Stop services in reverse order (Frontends -> Backends -> Infra)
echo -e "\n${YELLOW}Stopping Frontend Services...${NC}"
cd "$ROOT_DIR/fe/vdbas_exp_fe" && docker compose down
cd "$ROOT_DIR/fe/vdbas_host" && docker compose down

echo -e "\n${YELLOW}Stopping Backend Services...${NC}"
cd "$ROOT_DIR/be/vdbas_exp_be" && docker compose down
cd "$ROOT_DIR/be/vdbas_quantri_be" && docker compose down

echo -e "\n${YELLOW}Stopping Infrastructure (Database)...${NC}"
cd "$ROOT_DIR/be/oracle-db" && docker compose down

echo -e "\n${GREEN}========================================================${NC}"
echo -e "${GREEN}        All dockerized services stopped.                ${NC}"
echo -e "${GREEN}========================================================${NC}"
