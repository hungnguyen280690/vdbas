#!/bin/bash

# Configuration and colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

ROOT_DIR="$(pwd)"

echo -e "${BLUE}========================================================${NC}"
echo -e "${BLUE}    VDBAS Docker Compose Run All Services Utility       ${NC}"
echo -e "${BLUE}========================================================${NC}"

# 1. Start Infrastructure (Database)
echo -e "\n${YELLOW}[1/5] Starting Oracle Database...${NC}"
cd "$ROOT_DIR/be/oracle-db" || exit 1
docker compose up -d

# 2. Build Shared Backend Library
echo -e "\n${YELLOW}[2/5] Ensuring vdbas-common is built...${NC}"
if [ ! -f "$HOME/.m2/repository/com/fis/vdbas/vdbas-common/1.0.0-SNAPSHOT/vdbas-common-1.0.0-SNAPSHOT.jar" ]; then
    echo -e "${YELLOW}vdbas-common jar not found. Compiling now...${NC}"
    cd "$ROOT_DIR/be/vdbas_common" || exit 1
    mvn clean install -DskipTests
else
    echo -e "${GREEN}vdbas-common library is already compiled.${NC}"
fi

# 3. Start Backends
echo -e "\n${YELLOW}[3/5] Starting Backend Services...${NC}"

echo -e "${BLUE}Starting Admin Backend (vdbas_quantri_be)...${NC}"
cd "$ROOT_DIR/be/vdbas_quantri_be" || exit 1
docker compose up -d --build

echo -e "${BLUE}Starting Expense Backend (vdbas_exp_be)...${NC}"
cd "$ROOT_DIR/be/vdbas_exp_be" || exit 1
docker compose up -d --build

# 4. Start Frontends
echo -e "\n${YELLOW}[4/5] Starting Frontend Services...${NC}"

echo -e "${BLUE}Starting Host Frontend (vdbas_host)...${NC}"
cd "$ROOT_DIR/fe/vdbas_host" || exit 1
docker compose up -d --build

echo -e "${BLUE}Starting Expense Frontend (vdbas_exp_fe)...${NC}"
cd "$ROOT_DIR/fe/vdbas_exp_fe" || exit 1
docker compose up -d --build

# 5. Display Status
echo -e "\n${GREEN}========================================================================${NC}"
echo -e "${GREEN}              ALL SERVICES ARE STARTING VIA DOCKER COMPOSE              ${NC}"
echo -e "${GREEN}========================================================================${NC}"
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" | grep -E "vdbas|oracle"

echo -e "\n${YELLOW}To view logs, you can use:${NC}"
echo -e "  - Admin BE:   ${BLUE}docker logs -f vdbas-quantri-api${NC}"
echo -e "  - Expense BE: ${BLUE}docker logs -f vdbas-exp-api${NC}"
echo -e "  - Host FE:    ${BLUE}docker logs -f vdbas-host${NC}"
echo -e "  - Expense FE: ${BLUE}docker logs -f vdbas-exp-fe${NC}"
echo -e "\n${RED}To stop all services, run: ./docker_stop_all.sh (once created) or manually stop containers.${NC}"
echo -e "${GREEN}========================================================================${NC}"
